alpha = 1
--assert (0 == 1)
print("inAssert")

