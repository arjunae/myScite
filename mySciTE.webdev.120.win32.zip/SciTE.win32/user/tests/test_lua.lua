
-- hello world lua program 
io.write("\"Yo...\"")
print ("Hello World!")
