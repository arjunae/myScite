-- Windows requires this for us to immediately see all lua output.
io.stdout:setvbuf("no")
--print("startupScript_reload")

defaultHome = props["SciteDefaultHome"].."\\user"
package.path =  package.path ..";"..defaultHome.."\\Addons\\?.lua;".. ";"..defaultHome.."\\Addons\\lua\\lua\\?.lua;"
package.path=package.path..";C:\\Program Files (x86)\\Lua\\5.1\\lua\\?.lua"
package.path = package.path .. ";"..defaultHome.."\\Addons\\lua\\mod-extman\\?.lua;"
package.cpath = package.cpath .. ";"..defaultHome.."\\Addons\\lua\\c\\?.dll;"

--~ If available, use spawner-ex to help reduce flickering within scite_popen
local pathSpawner= props["spawner.extension.path"]
if not pathSpawner~="" then
 fnInit,err= package.loadlib(pathSpawner.."/spawner-ex.dll",'luaopen_spawner')
 if not err then fnInit() end
end

--lua >=5.2.x renamed functions: 
local unpack = table.unpack or unpack
math.mod=math.fmod or math.mod
string.gfind=string.gmatch or string.gfind
--lua >=5.2.x replaced table.getn(x) with #x

-- Load extman.lua (also "eventmanager.lua")
dofile(props["SciteDefaultHome"]..'\\user\\Addons\\lua\\mod-extman\\extman.lua')

-- ################################
-- ################## Lua Samples #####################
-- ################################

function markLinks()
--
-- search for textlinks and highlight them http://bla.de/bla
--
	local marker= 1
	prefix="http[:|s]+//"  -- Rules: Begins with http(s):// 
	body="[a-zA-Z0-9]?." 	-- followed by a word  (eg www or the domain)
	suffix="[^ \r\n\"\'<]+" 	-- ends with space, newline < " or '
	mask=prefix..body..suffix 
	EditorClearMarks(marker)
	local s,e = editor:findtext( mask, SCFIND_REGEXP, 0)
	while s do
		EditorMarkText(s, e-s, marker) 
		s,e =  editor:findtext( mask, SCFIND_REGEXP, s+1)
	end
end

function OnOpen(p)
	 markLinks()
end

function OnSwitchFile(p)
	scite.SendEditor(SCI_SETCARETFORE, 0x615DA1) 	-- Neals funny Cursor colors :) for loadFile / bufferSwitch   
	markLinks()
end

-- Test MenuCommand
-- scite.MenuCommand(IDM_MONOFONT)
