function do_breakpoint()
end

function do_next()
end

function do_temp_breakpoint()
end

function do_kill()
end

function do_inspect()
end

function do_locals()
end

function do_watch()
end

function do_backtrace()
end

function do_finish()
end

function do_up()
end

function do_down()
end
