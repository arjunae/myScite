-- fxSvgViewer (Lua version)
-- (c) Valentin Schmidt 2016

A simple SVG Viewer based on:

 - Lua v5.1 (https://www.lua.org/)
 - lqt (https://github.com/mkottman/lqt) 
 - Qt v4.7.4 (http://qt.apidoc.info/4.7.4/)

License: WTFPL 2.0

You can find a published standalone version for Windows at:
http://valentin.dasdeck.com/projects/scite_sidebar/published_projects/
