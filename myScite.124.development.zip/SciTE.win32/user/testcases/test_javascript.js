/* build@ cscript.exe //E:jscript /NOLOGO //D $(FilePath) '
	*  .... Doc Comments seem to be okay.
*/

// Check syntax Highlitening and multiline calltips.
function nameMe(str){
	$("#some_content").click (this, function() {
		writeln("click_main_content");
		var MyVeryLongVar = MyVeryLongVar + 20 - 0xA + 2; 
		var win = window("Test").callbacks.add(cele);
		str.replace(/ ^['"]/, "");
	})
}

// Test -> F5 ("Go" cmd)
http = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
http.Open("GET", "https://raw.githubusercontent.com/arjunae/myScite/master/.gitattributes", false);
http.Send;
WScript.Echo("http.StatusText:" + http.StatusText + "\nhttp.responseText:\n " + http.responseText);
