-- Copyright 2006-2018 Mitchell mitchell.att.foicica.com. See License.txt.
-- Text LPeg lexer.

return require('lexer').new('text')
